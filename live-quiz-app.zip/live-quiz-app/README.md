# Live Quiz

A small Kahoot-style live quiz app. One host runs the quiz from a big screen,
players join from their phones with a 6-digit PIN and no account.

**Stack:** Next.js (pages router) · Firebase Authentication (host login) ·
Firestore (data + realtime updates) · Tailwind CSS.

## 1. Create a Firebase project

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → **Add project**.
2. **Build → Authentication → Get started → Sign-in method → Email/Password → Enable.**
   This is the only sign-in method used — hosts log in with email/password,
   players never sign in.
3. **Build → Firestore Database → Create database** (start in production mode).
4. **Project settings → General → Your apps → Add app → Web**, copy the config
   object it gives you.

## 2. Configure the app

```bash
cp .env.local.example .env.local
```

Paste the values from step 1.4 into `.env.local`.

## 3. Install and run

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## 4. Deploy the Firestore rules

The rules in `firestore.rules` are required — without them, no one can read
or write data. Using the Firebase CLI:

```bash
npm install -g firebase-tools
firebase login
firebase init firestore   # point it at this folder, keep the existing firestore.rules
firebase deploy --only firestore:rules
```

No composite indexes are needed — every query in the app filters on a single field.

## 5. Deploy the app

Either works:

- **Vercel** (simplest for Next.js): `vercel` (or connect the repo in the Vercel dashboard) and add the same env vars from `.env.local` in the project settings.
- **Firebase Hosting**: `next build && next export` isn't used here (the app needs server-rendered routing for query params), so prefer Vercel, or deploy with Firebase App Hosting, which supports Next.js directly.

## How it works

- **Host** logs in at `/host/login`, builds a quiz at `/host/quiz/create` (title
  + questions, each with 4 options, a correct answer, and a timer), then hits
  **Start Quiz** on `/host/dashboard`. That creates a `sessions` document with
  a random 6-digit `gamePin` and opens `/host/live`.
- **Players** go to `/join`, enter the PIN + a name (no account), and get
  added to that session's `players` subcollection. They land on `/play`,
  which mirrors the session's live status (`lobby` → `question` → `reveal` →
  `ended`).
- The host's **Start Question** / **Next Question** buttons move the session
  through its questions. Every screen (host and player) listens to the same
  `sessions/{id}` document with `onSnapshot`, so they all update instantly.
- When a player answers, faster correct answers score more: 1000 points for
  an instant correct answer, tapering to a 100-point floor as the timer runs
  out (see `lib/quizLogic.js`).
- After the last question, the session status becomes `ended` and everyone is
  routed to `/leaderboard`.

## Data model (Firestore)

```
users/{uid}                  { email, role }
quizzes/{quizId}             { title, hostId, questions: [
                                  { question, options: [4 strings], correctIndex, timerSeconds }
                                ] }
sessions/{sessionId}         { quizId, hostId, quizTitle, gamePin, status,
                                currentQuestionIndex, questionStartedAt, questionCount }
  sessions/{id}/players/{playerId}   { name, score }
  sessions/{id}/answers/{answerId}   { playerId, questionIndex, selectedIndex, correct, points }
```

`status` is one of `lobby`, `question`, `reveal`, `ended`.

## Security notes (read before using this for anything real)

Players never sign in, so Firestore can't prove a score update really came
from that player's browser — the rules in `firestore.rules` are deliberately
minimal to match that. For a real deployment, consider:

- Turning on **anonymous auth** for players so each has a `uid` the rules can
  check against (`request.auth.uid == playerId`).
- Enabling **Firebase App Check** to block traffic that isn't your app.
- Moving score calculation into a **Cloud Function** triggered on answer
  creation, instead of trusting the points the client computed.

None of this is required to run the app as described in the brief — it's
what you'd add before opening it up beyond a trusted room.

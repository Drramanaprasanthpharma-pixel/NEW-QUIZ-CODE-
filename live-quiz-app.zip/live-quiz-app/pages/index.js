import Head from "next/head";
import { useRouter } from "next/router";

export default function Home() {
  const router = useRouter();

  return (
    <>
      <Head>
        <title>Live Quiz</title>
        <meta name="description" content="Host or join a live multiple-choice quiz." />
      </Head>
      <main className="min-h-screen bg-ink text-paper flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-16">
          <div className="w-full max-w-md text-center">
            <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-4">
              LIVE QUIZ
            </p>
            <h1 className="font-display text-4xl sm:text-5xl font-semibold leading-tight mb-4">
              Ask a room a question.
              <br />
              Watch it answer at once.
            </h1>
            <p className="text-mist text-base mb-10">
              Host reads the questions out loud, everyone answers from their
              own phone, the board updates live. No player accounts needed.
            </p>

            <div className="flex flex-col gap-3">
              <button
                onClick={() => router.push("/join")}
                className="w-full bg-marigold text-ink font-display font-semibold text-lg py-4 rounded-block hover:brightness-105 active:scale-[0.99] transition"
              >
                Join a game
              </button>
              <button
                onClick={() => router.push("/host/login")}
                className="w-full border border-line text-paper font-display font-medium text-lg py-4 rounded-block hover:border-mist transition"
              >
                Host a quiz
              </button>
            </div>
          </div>
        </div>

        <footer className="text-center text-mist text-xs pb-6">
          Built with Firebase &amp; Next.js
        </footer>
      </main>
    </>
  );
}

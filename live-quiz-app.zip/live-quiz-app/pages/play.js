import Head from "next/head";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import {
  doc,
  getDoc,
  onSnapshot,
  setDoc,
  serverTimestamp,
  updateDoc,
  increment,
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { SESSION_STATUS, calculatePoints, sortByScoreDesc } from "../lib/quizLogic";
import { collection } from "firebase/firestore";

export default function Play() {
  const router = useRouter();
  const [identity, setIdentity] = useState(undefined); // undefined = checking
  const [session, setSession] = useState(null);
  const [quiz, setQuiz] = useState(null);
  const [player, setPlayer] = useState(null);
  const [players, setPlayers] = useState([]);
  const [now, setNow] = useState(Date.now());
  const [myAnswer, setMyAnswer] = useState(null); // { selectedIndex, correct, points } for current question
  const [checkingAnswer, setCheckingAnswer] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  // Load identity from localStorage
  useEffect(() => {
    const raw = typeof window !== "undefined" && localStorage.getItem("liveQuizPlayer");
    if (!raw) {
      router.replace("/join");
      return;
    }
    setIdentity(JSON.parse(raw));
  }, [router]);

  useEffect(() => {
    if (!identity) return;
    const unsub = onSnapshot(doc(db, "sessions", identity.sessionId), (snap) => {
      if (snap.exists()) setSession({ id: snap.id, ...snap.data() });
      else setError("This quiz session no longer exists.");
    });
    return unsub;
  }, [identity]);

  useEffect(() => {
    if (!identity) return;
    const unsub = onSnapshot(
      doc(db, "sessions", identity.sessionId, "players", identity.playerId),
      (snap) => {
        if (snap.exists()) setPlayer({ id: snap.id, ...snap.data() });
      }
    );
    return unsub;
  }, [identity]);

  useEffect(() => {
    if (!identity) return;
    const unsub = onSnapshot(
      collection(db, "sessions", identity.sessionId, "players"),
      (snap) => setPlayers(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    );
    return unsub;
  }, [identity]);

  useEffect(() => {
    if (!session?.quizId) return;
    getDoc(doc(db, "quizzes", session.quizId)).then((snap) => {
      if (snap.exists()) setQuiz({ id: snap.id, ...snap.data() });
    });
  }, [session?.quizId]);

  // Check whether this player already answered the current question
  useEffect(() => {
    if (!identity || session?.currentQuestionIndex == null) return;
    setCheckingAnswer(true);
    setMyAnswer(null);
    const answerId = `${identity.playerId}_${session.currentQuestionIndex}`;
    getDoc(doc(db, "sessions", identity.sessionId, "answers", answerId)).then((snap) => {
      if (snap.exists()) setMyAnswer(snap.data());
      setCheckingAnswer(false);
    });
  }, [identity, session?.currentQuestionIndex]);

  useEffect(() => {
    if (session?.status !== SESSION_STATUS.QUESTION) return;
    const interval = setInterval(() => setNow(Date.now()), 200);
    return () => clearInterval(interval);
  }, [session?.status]);

  const currentQuestion = useMemo(() => {
    if (!quiz || session?.currentQuestionIndex == null) return null;
    return quiz.questions[session.currentQuestionIndex] || null;
  }, [quiz, session?.currentQuestionIndex]);

  const elapsedMs = useMemo(() => {
    if (!session?.questionStartedAt?.toMillis) return 0;
    return now - session.questionStartedAt.toMillis();
  }, [now, session?.questionStartedAt]);

  const remainingSeconds = currentQuestion
    ? Math.max(currentQuestion.timerSeconds - elapsedMs / 1000, 0)
    : 0;
  const pct = currentQuestion
    ? Math.max((remainingSeconds / currentQuestion.timerSeconds) * 100, 0)
    : 0;

  const leaderboard = useMemo(() => sortByScoreDesc(players), [players]);
  const myRank = leaderboard.findIndex((p) => p.id === identity?.playerId) + 1;

  async function submitAnswer(selectedIndex) {
    if (!currentQuestion || myAnswer || submitting) return;
    setSubmitting(true);
    try {
      const correct = selectedIndex === currentQuestion.correctIndex;
      const points = calculatePoints({
        correct,
        elapsedMs,
        timerSeconds: currentQuestion.timerSeconds,
      });
      const answerId = `${identity.playerId}_${session.currentQuestionIndex}`;
      await setDoc(doc(db, "sessions", identity.sessionId, "answers", answerId), {
        playerId: identity.playerId,
        playerName: identity.name,
        questionIndex: session.currentQuestionIndex,
        selectedIndex,
        correct,
        points,
        answeredAt: serverTimestamp(),
      });
      if (points > 0) {
        await updateDoc(doc(db, "sessions", identity.sessionId, "players", identity.playerId), {
          score: increment(points),
        });
      }
      setMyAnswer({ selectedIndex, correct, points });
    } catch (err) {
      setError("Couldn't submit your answer. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (error) return <CenteredMessage text={error} />;
  if (identity === undefined || !session) return <CenteredMessage text="Loading…" />;

  return (
    <>
      <Head>
        <title>Playing · Live Quiz</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper px-5 py-6 flex flex-col">
        <header className="flex items-center justify-between mb-6">
          <span className="text-sm text-mist">{identity.name}</span>
          <span className="font-display font-semibold text-marigold">
            {player?.score ?? 0} pts
          </span>
        </header>

        {session.status === SESSION_STATUS.LOBBY && (
          <LobbyWait name={identity.name} playerCount={players.length} />
        )}

        {session.status === SESSION_STATUS.QUESTION && currentQuestion && (
          <QuestionScreen
            question={currentQuestion}
            pct={pct}
            secondsLeft={Math.ceil(remainingSeconds)}
            checking={checkingAnswer}
            myAnswer={myAnswer}
            submitting={submitting}
            onSelect={submitAnswer}
          />
        )}

        {session.status === SESSION_STATUS.REVEAL && currentQuestion && (
          <RevealScreen
            question={currentQuestion}
            myAnswer={myAnswer}
            myRank={myRank}
            totalPlayers={players.length}
          />
        )}

        {session.status === SESSION_STATUS.ENDED && (
          <EndedScreen
            onSeeLeaderboard={() =>
              router.push(`/leaderboard?session=${identity.sessionId}`)
            }
          />
        )}
      </main>
    </>
  );
}

function LobbyWait({ name, playerCount }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center">
      <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-4">
        YOU'RE IN
      </p>
      <h1 className="font-display text-2xl font-semibold mb-2">
        Hey {name}, sit tight
      </h1>
      <p className="text-mist text-sm">
        Waiting for the host to start · {playerCount} player
        {playerCount === 1 ? "" : "s"} in the lobby
      </p>
    </div>
  );
}

function QuestionScreen({
  question,
  pct,
  secondsLeft,
  checking,
  myAnswer,
  submitting,
  onSelect,
}) {
  const optionStyles = [
    "bg-marigold text-ink",
    "bg-teal text-ink",
    "bg-coral text-ink",
    "bg-panelLight text-paper border border-line",
  ];

  if (checking) return <CenteredMessage text="Loading question…" />;

  if (myAnswer) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <p className="font-display text-2xl font-semibold mb-2">
          Answer locked in
        </p>
        <p className="text-mist text-sm">Waiting for the other players…</p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-xl font-semibold flex-1 pr-4">
          {question.question}
        </h2>
        <div
          className="timer-ring w-14 h-14 rounded-full flex items-center justify-center shrink-0"
          style={{ "--pct": pct }}
        >
          <div className="timer-ring-inner w-10 h-10 rounded-full flex items-center justify-center">
            <span className="font-display font-semibold text-sm">
              {secondsLeft}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
        {question.options.map((opt, i) => (
          <button
            key={i}
            disabled={submitting}
            onClick={() => onSelect(i)}
            className={`${optionStyles[i]} rounded-block px-5 py-8 text-lg font-display font-semibold text-left active:scale-[0.98] transition disabled:opacity-70`}
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}

function RevealScreen({ question, myAnswer, myRank, totalPlayers }) {
  const didAnswer = !!myAnswer;
  const wasCorrect = myAnswer?.correct;

  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center">
      {!didAnswer ? (
        <>
          <p className="font-display text-2xl font-semibold mb-2">Time's up</p>
          <p className="text-mist text-sm">You didn't answer in time.</p>
        </>
      ) : wasCorrect ? (
        <>
          <p className="text-teal pin-display text-sm tracking-[0.3em] mb-3">
            CORRECT
          </p>
          <p className="font-display text-4xl font-semibold mb-2">
            +{myAnswer.points}
          </p>
          <p className="text-mist text-sm">points this round</p>
        </>
      ) : (
        <>
          <p className="text-coral pin-display text-sm tracking-[0.3em] mb-3">
            NOT QUITE
          </p>
          <p className="font-display text-xl font-semibold mb-2">
            The correct answer was
          </p>
          <p className="text-paper">{question.options[question.correctIndex]}</p>
        </>
      )}

      {myRank > 0 && (
        <p className="text-mist text-sm mt-8">
          You're rank {myRank} of {totalPlayers}
        </p>
      )}
      <p className="text-mist text-xs mt-2">Waiting for the host…</p>
    </div>
  );
}

function EndedScreen({ onSeeLeaderboard }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center">
      <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-4">
        QUIZ COMPLETE
      </p>
      <h1 className="font-display text-2xl font-semibold mb-8">
        Thanks for playing!
      </h1>
      <button
        onClick={onSeeLeaderboard}
        className="bg-marigold text-ink font-display font-semibold text-lg px-8 py-4 rounded-block hover:brightness-105 transition"
      >
        See final results
      </button>
    </div>
  );
}

function CenteredMessage({ text }) {
  return (
    <main className="min-h-screen bg-ink text-mist flex items-center justify-center text-center px-6">
      <p>{text}</p>
    </main>
  );
}

import Head from "next/head";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import { collection, doc, onSnapshot } from "firebase/firestore";
import { db } from "../lib/firebase";
import { sortByScoreDesc } from "../lib/quizLogic";

export default function LeaderboardPage() {
  const router = useRouter();
  const { session: sessionId } = router.query;
  const [session, setSession] = useState(null);
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    if (!sessionId) return;
    const unsub = onSnapshot(doc(db, "sessions", sessionId), (snap) => {
      if (snap.exists()) setSession({ id: snap.id, ...snap.data() });
    });
    return unsub;
  }, [sessionId]);

  useEffect(() => {
    if (!sessionId) return;
    const unsub = onSnapshot(
      collection(db, "sessions", sessionId, "players"),
      (snap) => setPlayers(snap.docs.map((d) => ({ id: d.id, ...d.data() })))
    );
    return unsub;
  }, [sessionId]);

  const ranked = useMemo(() => sortByScoreDesc(players), [players]);
  const [first, second, third, ...rest] = ranked;

  return (
    <>
      <Head>
        <title>Leaderboard · Live Quiz</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper px-6 py-12 flex flex-col items-center">
        <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-2">
          FINAL RESULTS
        </p>
        <h1 className="font-display text-3xl font-semibold mb-10 text-center">
          {session?.quizTitle || "Live Quiz"}
        </h1>

        {ranked.length === 0 ? (
          <p className="text-mist">No players took part.</p>
        ) : (
          <div className="w-full max-w-md">
            <div className="grid grid-cols-3 items-end gap-3 mb-10">
              <Podium place={2} player={second} height="h-24" />
              <Podium place={1} player={first} height="h-32" highlight />
              <Podium place={3} player={third} height="h-16" />
            </div>

            {rest.length > 0 && (
              <ul className="flex flex-col gap-2">
                {rest.map((p, i) => (
                  <li
                    key={p.id}
                    className="flex items-center justify-between bg-panel border border-line rounded-block px-4 py-3"
                  >
                    <span className="text-mist">
                      {i + 4}. {p.name}
                    </span>
                    <span className="font-display font-semibold">
                      {p.score || 0}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <button
          onClick={() => router.push("/")}
          className="mt-10 border border-line text-paper font-display px-6 py-3 rounded-block hover:border-mist transition"
        >
          Back to home
        </button>
      </main>
    </>
  );
}

function Podium({ place, player, height, highlight }) {
  return (
    <div className="flex flex-col items-center">
      <p className="font-display font-semibold text-sm mb-1 text-center truncate w-full">
        {player ? player.name : "—"}
      </p>
      <p className="text-marigold text-xs mb-2">{player ? player.score : 0}</p>
      <div
        className={`w-full rounded-t-block flex items-start justify-center pt-2 ${height} ${
          highlight ? "bg-marigold text-ink" : "bg-panelLight text-paper"
        }`}
      >
        <span className="font-display font-bold text-2xl">{place}</span>
      </div>
    </div>
  );
}

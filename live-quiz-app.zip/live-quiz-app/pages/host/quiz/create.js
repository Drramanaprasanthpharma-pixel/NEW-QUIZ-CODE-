import Head from "next/head";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { onAuthStateChanged } from "firebase/auth";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../../../lib/firebase";

function emptyQuestion() {
  return {
    question: "",
    options: ["", "", "", ""],
    correctIndex: 0,
    timerSeconds: 20,
  };
}

export default function CreateQuiz() {
  const router = useRouter();
  const [user, setUser] = useState(undefined);
  const [title, setTitle] = useState("");
  const [questions, setQuestions] = useState([emptyQuestion()]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (!u) router.replace("/host/login");
      else setUser(u);
    });
    return unsub;
  }, [router]);

  function updateQuestion(index, patch) {
    setQuestions((prev) =>
      prev.map((q, i) => (i === index ? { ...q, ...patch } : q))
    );
  }

  function updateOption(qIndex, oIndex, value) {
    setQuestions((prev) =>
      prev.map((q, i) => {
        if (i !== qIndex) return q;
        const options = [...q.options];
        options[oIndex] = value;
        return { ...q, options };
      })
    );
  }

  function addQuestion() {
    setQuestions((prev) => [...prev, emptyQuestion()]);
  }

  function removeQuestion(index) {
    setQuestions((prev) => prev.filter((_, i) => i !== index));
  }

  function validate() {
    if (!title.trim()) return "Give your quiz a title.";
    if (questions.length === 0) return "Add at least one question.";
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q.question.trim()) return `Question ${i + 1} needs text.`;
      if (q.options.some((o) => !o.trim()))
        return `Question ${i + 1} needs all 4 answer options filled in.`;
      if (!q.timerSeconds || q.timerSeconds < 5)
        return `Question ${i + 1} needs a timer of at least 5 seconds.`;
    }
    return "";
  }

  async function handleSave(e) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }
    setError("");
    setSaving(true);
    try {
      await addDoc(collection(db, "quizzes"), {
        title: title.trim(),
        hostId: user.uid,
        questions: questions.map((q) => ({
          question: q.question.trim(),
          options: q.options.map((o) => o.trim()),
          correctIndex: q.correctIndex,
          timerSeconds: Number(q.timerSeconds),
        })),
        createdAt: serverTimestamp(),
      });
      router.push("/host/dashboard");
    } catch (err) {
      setError("Couldn't save the quiz. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  if (user === undefined) return null;

  return (
    <>
      <Head>
        <title>Create Quiz · Live Quiz</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper px-6 py-10">
        <div className="max-w-2xl mx-auto pb-28">
          <p className="pin-display text-marigold text-xs tracking-[0.3em] mb-1">
            NEW QUIZ
          </p>
          <h1 className="font-display text-2xl font-semibold mb-8">
            Create a quiz
          </h1>

          <form onSubmit={handleSave}>
            <div className="mb-8">
              <label className="block text-xs text-mist mb-1.5" htmlFor="title">
                Quiz title
              </label>
              <input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Friday Trivia Night"
                className="w-full bg-panel border border-line rounded-block px-4 py-3 text-paper placeholder:text-mist/60"
              />
            </div>

            <div className="flex flex-col gap-6">
              {questions.map((q, qIndex) => (
                <div
                  key={qIndex}
                  className="bg-panel border border-line rounded-block p-5"
                >
                  <div className="flex items-center justify-between mb-4">
                    <p className="font-display font-semibold text-mist">
                      Question {qIndex + 1}
                    </p>
                    {questions.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeQuestion(qIndex)}
                        className="text-coral text-xs hover:underline"
                      >
                        Remove
                      </button>
                    )}
                  </div>

                  <input
                    value={q.question}
                    onChange={(e) =>
                      updateQuestion(qIndex, { question: e.target.value })
                    }
                    placeholder="Type the question"
                    className="w-full bg-ink border border-line rounded-block px-4 py-3 mb-4 text-paper placeholder:text-mist/60"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                    {q.options.map((opt, oIndex) => (
                      <label
                        key={oIndex}
                        className={`flex items-center gap-3 rounded-block border px-3 py-2.5 cursor-pointer transition ${
                          q.correctIndex === oIndex
                            ? "border-teal bg-teal/10"
                            : "border-line bg-ink"
                        }`}
                      >
                        <input
                          type="radio"
                          name={`correct-${qIndex}`}
                          checked={q.correctIndex === oIndex}
                          onChange={() =>
                            updateQuestion(qIndex, { correctIndex: oIndex })
                          }
                          className="accent-teal"
                        />
                        <input
                          value={opt}
                          onChange={(e) =>
                            updateOption(qIndex, oIndex, e.target.value)
                          }
                          placeholder={`Option ${oIndex + 1}`}
                          className="flex-1 bg-transparent placeholder:text-mist/60 text-paper focus:outline-none"
                        />
                      </label>
                    ))}
                  </div>
                  <p className="text-mist text-xs mb-3">
                    Select the circle next to the correct answer.
                  </p>

                  <div className="flex items-center gap-3">
                    <label className="text-xs text-mist" htmlFor={`timer-${qIndex}`}>
                      Timer (seconds)
                    </label>
                    <input
                      id={`timer-${qIndex}`}
                      type="number"
                      min={5}
                      max={120}
                      value={q.timerSeconds}
                      onChange={(e) =>
                        updateQuestion(qIndex, { timerSeconds: e.target.value })
                      }
                      className="w-24 bg-ink border border-line rounded-block px-3 py-2 text-paper"
                    />
                  </div>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={addQuestion}
              className="w-full mt-6 border border-dashed border-line text-mist font-display text-sm py-3 rounded-block hover:border-mist hover:text-paper transition"
            >
              + Add another question
            </button>

            {error && (
              <p className="text-coral text-sm mt-5" role="alert">
                {error}
              </p>
            )}

            <div className="fixed bottom-0 left-0 right-0 bg-ink/95 backdrop-blur border-t border-line px-6 py-4">
              <div className="max-w-2xl mx-auto flex gap-3">
                <button
                  type="button"
                  onClick={() => router.push("/host/dashboard")}
                  className="flex-1 border border-line text-paper font-display py-3 rounded-block hover:border-mist transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 bg-marigold text-ink font-display font-semibold py-3 rounded-block hover:brightness-105 transition disabled:opacity-60"
                >
                  {saving ? "Saving…" : "Save quiz"}
                </button>
              </div>
            </div>
          </form>
        </div>
      </main>
    </>
  );
}

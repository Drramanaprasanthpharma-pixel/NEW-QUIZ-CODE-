import Head from "next/head";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { onAuthStateChanged, signOut } from "firebase/auth";
import {
  addDoc,
  collection,
  getDocs,
  query,
  serverTimestamp,
  where,
} from "firebase/firestore";
import { auth, db } from "../../lib/firebase";
import { SESSION_STATUS, generateGamePin } from "../../lib/quizLogic";

export default function HostDashboard() {
  const router = useRouter();
  const [user, setUser] = useState(undefined); // undefined = checking, null = signed out
  const [quizzes, setQuizzes] = useState([]);
  const [loadingQuizzes, setLoadingQuizzes] = useState(true);
  const [startingId, setStartingId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (!u) {
        router.replace("/host/login");
      } else {
        setUser(u);
      }
    });
    return unsub;
  }, [router]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      setLoadingQuizzes(true);
      const q = query(collection(db, "quizzes"), where("hostId", "==", user.uid));
      const snap = await getDocs(q);
      setQuizzes(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
      setLoadingQuizzes(false);
    })();
  }, [user]);

  async function startQuiz(quiz) {
    setError("");
    setStartingId(quiz.id);
    try {
      if (!quiz.questions || quiz.questions.length === 0) {
        setError("Add at least one question before starting this quiz.");
        return;
      }
      const gamePin = generateGamePin();
      const sessionRef = await addDoc(collection(db, "sessions"), {
        quizId: quiz.id,
        hostId: user.uid,
        quizTitle: quiz.title,
        gamePin,
        status: SESSION_STATUS.LOBBY,
        currentQuestionIndex: -1,
        questionCount: quiz.questions.length,
        questionStartedAt: null,
        createdAt: serverTimestamp(),
      });
      router.push(`/host/live?session=${sessionRef.id}`);
    } catch (err) {
      setError("Couldn't start the quiz. Please try again.");
    } finally {
      setStartingId(null);
    }
  }

  if (user === undefined) {
    return <CenteredMessage text="Checking your session…" />;
  }

  return (
    <>
      <Head>
        <title>Dashboard · Live Quiz</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper px-6 py-10">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div>
              <p className="pin-display text-marigold text-xs tracking-[0.3em] mb-1">
                HOST DASHBOARD
              </p>
              <h1 className="font-display text-2xl font-semibold">
                {user?.email}
              </h1>
            </div>
            <button
              onClick={() => signOut(auth)}
              className="text-sm text-mist hover:text-paper transition"
            >
              Log out
            </button>
          </div>

          <button
            onClick={() => router.push("/host/quiz/create")}
            className="w-full mb-8 bg-marigold text-ink font-display font-semibold text-base py-3.5 rounded-block hover:brightness-105 active:scale-[0.99] transition"
          >
            + Create a new quiz
          </button>

          {error && (
            <p className="text-coral text-sm mb-4" role="alert">
              {error}
            </p>
          )}

          <h2 className="font-display text-lg font-semibold mb-3 text-mist">
            Your quizzes
          </h2>

          {loadingQuizzes ? (
            <p className="text-mist text-sm">Loading…</p>
          ) : quizzes.length === 0 ? (
            <p className="text-mist text-sm">
              No quizzes yet. Create your first one above.
            </p>
          ) : (
            <ul className="flex flex-col gap-3">
              {quizzes.map((quiz) => (
                <li
                  key={quiz.id}
                  className="bg-panel border border-line rounded-block px-5 py-4 flex items-center justify-between gap-4"
                >
                  <div>
                    <p className="font-display font-semibold">{quiz.title}</p>
                    <p className="text-mist text-xs">
                      {(quiz.questions || []).length} question
                      {(quiz.questions || []).length === 1 ? "" : "s"}
                    </p>
                  </div>
                  <button
                    onClick={() => startQuiz(quiz)}
                    disabled={startingId === quiz.id}
                    className="shrink-0 bg-teal text-ink font-display font-semibold text-sm px-4 py-2.5 rounded-block hover:brightness-105 transition disabled:opacity-60"
                  >
                    {startingId === quiz.id ? "Starting…" : "Start Quiz"}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
    </>
  );
}

function CenteredMessage({ text }) {
  return (
    <main className="min-h-screen bg-ink text-mist flex items-center justify-center">
      <p>{text}</p>
    </main>
  );
}

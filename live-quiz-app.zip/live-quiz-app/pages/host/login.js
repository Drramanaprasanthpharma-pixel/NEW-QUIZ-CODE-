import Head from "next/head";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../../lib/firebase";

export default function HostLogin() {
  const router = useRouter();
  const [mode, setMode] = useState("login"); // "login" | "signup"
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user) router.replace("/host/dashboard");
    });
    return unsub;
  }, [router]);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (mode === "signup") {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, "users", cred.user.uid), {
          email,
          role: "host",
          createdAt: serverTimestamp(),
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      router.push("/host/dashboard");
    } catch (err) {
      setError(friendlyError(err.code));
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Head>
        <title>Host Login · Live Quiz</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-sm">
          <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-3">
            HOST
          </p>
          <h1 className="font-display text-3xl font-semibold mb-1">
            {mode === "login" ? "Welcome back" : "Create your host account"}
          </h1>
          <p className="text-mist text-sm mb-8">
            {mode === "login"
              ? "Log in to build and run your quizzes."
              : "Set an email and password to start hosting."}
          </p>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="block text-xs text-mist mb-1.5" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-panel border border-line rounded-block px-4 py-3 text-paper placeholder:text-mist/60"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-xs text-mist mb-1.5" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-panel border border-line rounded-block px-4 py-3 text-paper placeholder:text-mist/60"
                placeholder="At least 6 characters"
              />
            </div>

            {error && (
              <p className="text-coral text-sm" role="alert">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="mt-2 w-full bg-marigold text-ink font-display font-semibold text-lg py-3.5 rounded-block hover:brightness-105 active:scale-[0.99] transition disabled:opacity-60"
            >
              {busy ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}
            </button>
          </form>

          <button
            onClick={() => {
              setError("");
              setMode(mode === "login" ? "signup" : "login");
            }}
            className="mt-6 w-full text-center text-sm text-mist hover:text-paper transition"
          >
            {mode === "login"
              ? "Need a host account? Sign up"
              : "Already have an account? Log in"}
          </button>
        </div>
      </main>
    </>
  );
}

function friendlyError(code) {
  switch (code) {
    case "auth/invalid-email":
      return "That email address doesn't look right.";
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return "Email or password is incorrect.";
    case "auth/email-already-in-use":
      return "An account already exists for that email.";
    case "auth/weak-password":
      return "Password should be at least 6 characters.";
    default:
      return "Something went wrong. Please try again.";
  }
}

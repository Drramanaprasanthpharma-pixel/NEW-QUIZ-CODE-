import Head from "next/head";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import { onAuthStateChanged } from "firebase/auth";
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { auth, db } from "../../lib/firebase";
import { SESSION_STATUS, sortByScoreDesc } from "../../lib/quizLogic";

export default function HostLive() {
  const router = useRouter();
  const { session: sessionId } = router.query;

  const [user, setUser] = useState(undefined);
  const [session, setSession] = useState(null);
  const [quiz, setQuiz] = useState(null);
  const [players, setPlayers] = useState([]);
  const [answers, setAnswers] = useState([]);
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (!u) router.replace("/host/login");
      else setUser(u);
    });
    return unsub;
  }, [router]);

  // Session listener
  useEffect(() => {
    if (!sessionId) return;
    const unsub = onSnapshot(doc(db, "sessions", sessionId), (snap) => {
      if (snap.exists()) setSession({ id: snap.id, ...snap.data() });
    });
    return unsub;
  }, [sessionId]);

  // Quiz (questions) — fetched once we know quizId
  useEffect(() => {
    if (!session?.quizId) return;
    getDoc(doc(db, "quizzes", session.quizId)).then((snap) => {
      if (snap.exists()) setQuiz({ id: snap.id, ...snap.data() });
    });
  }, [session?.quizId]);

  // Players listener
  useEffect(() => {
    if (!sessionId) return;
    const q = query(collection(db, "sessions", sessionId, "players"));
    const unsub = onSnapshot(q, (snap) => {
      setPlayers(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [sessionId]);

  // Answers listener, scoped to the current question
  useEffect(() => {
    if (!sessionId || session?.currentQuestionIndex == null) return;
    const q = query(
      collection(db, "sessions", sessionId, "answers"),
      where("questionIndex", "==", session.currentQuestionIndex)
    );
    const unsub = onSnapshot(q, (snap) => {
      setAnswers(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [sessionId, session?.currentQuestionIndex]);

  // Local clock for the countdown ring
  useEffect(() => {
    if (session?.status !== SESSION_STATUS.QUESTION) return;
    const interval = setInterval(() => setNow(Date.now()), 200);
    return () => clearInterval(interval);
  }, [session?.status]);

  const currentQuestion = useMemo(() => {
    if (!quiz || session?.currentQuestionIndex == null) return null;
    return quiz.questions[session.currentQuestionIndex] || null;
  }, [quiz, session?.currentQuestionIndex]);

  const totalQuestions = quiz?.questions?.length || 0;
  const isLast = session?.currentQuestionIndex === totalQuestions - 1;

  const elapsedMs = useMemo(() => {
    if (!session?.questionStartedAt?.toMillis) return 0;
    return now - session.questionStartedAt.toMillis();
  }, [now, session?.questionStartedAt]);

  const remainingSeconds = currentQuestion
    ? Math.max(currentQuestion.timerSeconds - elapsedMs / 1000, 0)
    : 0;
  const pct = currentQuestion
    ? Math.max((remainingSeconds / currentQuestion.timerSeconds) * 100, 0)
    : 0;

  // Auto-reveal once the timer runs out.
  useEffect(() => {
    if (session?.status === SESSION_STATUS.QUESTION && currentQuestion && remainingSeconds <= 0) {
      revealAnswer();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remainingSeconds, session?.status]);

  const optionCounts = useMemo(() => {
    const counts = [0, 0, 0, 0];
    answers.forEach((a) => {
      if (a.selectedIndex >= 0 && a.selectedIndex < 4) counts[a.selectedIndex]++;
    });
    return counts;
  }, [answers]);

  const leaderboard = useMemo(() => sortByScoreDesc(players), [players]);

  async function startQuestion(index) {
    setBusy(true);
    try {
      await updateDoc(doc(db, "sessions", sessionId), {
        status: SESSION_STATUS.QUESTION,
        currentQuestionIndex: index,
        questionStartedAt: serverTimestamp(),
      });
    } finally {
      setBusy(false);
    }
  }

  async function revealAnswer() {
    if (session?.status !== SESSION_STATUS.QUESTION) return;
    await updateDoc(doc(db, "sessions", sessionId), {
      status: SESSION_STATUS.REVEAL,
    });
  }

  async function nextQuestion() {
    setBusy(true);
    try {
      if (isLast) {
        await updateDoc(doc(db, "sessions", sessionId), {
          status: SESSION_STATUS.ENDED,
        });
      } else {
        await startQuestion(session.currentQuestionIndex + 1);
      }
    } finally {
      setBusy(false);
    }
  }

  if (user === undefined || !session) {
    return <CenteredMessage text="Loading session…" />;
  }

  return (
    <>
      <Head>
        <title>Live · {session.quizTitle || "Quiz"}</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper px-6 py-8">
        <div className="max-w-3xl mx-auto">
          <header className="flex items-center justify-between mb-8">
            <div>
              <p className="text-mist text-xs tracking-[0.2em]">
                {session.quizTitle}
              </p>
              {totalQuestions > 0 && session.status !== SESSION_STATUS.LOBBY && (
                <p className="text-mist text-xs mt-0.5">
                  Question {session.currentQuestionIndex + 1} of {totalQuestions}
                </p>
              )}
            </div>
            <div className="text-right">
              <p className="text-mist text-[10px] tracking-[0.2em]">GAME PIN</p>
              <p className="pin-display text-2xl font-semibold text-marigold">
                {session.gamePin}
              </p>
            </div>
          </header>

          {session.status === SESSION_STATUS.LOBBY && (
            <LobbyView
              players={leaderboard}
              onStart={() => startQuestion(0)}
              busy={busy}
              hasQuestions={totalQuestions > 0}
            />
          )}

          {session.status === SESSION_STATUS.QUESTION && currentQuestion && (
            <QuestionView
              question={currentQuestion}
              pct={pct}
              secondsLeft={Math.ceil(remainingSeconds)}
              answeredCount={answers.length}
              totalPlayers={players.length}
              optionCounts={optionCounts}
              onReveal={revealAnswer}
            />
          )}

          {session.status === SESSION_STATUS.REVEAL && currentQuestion && (
            <RevealView
              question={currentQuestion}
              optionCounts={optionCounts}
              leaderboard={leaderboard}
              isLast={isLast}
              busy={busy}
              onNext={nextQuestion}
            />
          )}

          {session.status === SESSION_STATUS.ENDED && (
            <EndedView
              leaderboard={leaderboard}
              onViewLeaderboard={() =>
                router.push(`/leaderboard?session=${sessionId}`)
              }
            />
          )}
        </div>
      </main>
    </>
  );
}

function LobbyView({ players, onStart, busy, hasQuestions }) {
  return (
    <div>
      <div className="text-center mb-10">
        <p className="text-mist text-sm mb-2">Players join at</p>
        <p className="font-display text-xl mb-1">yourapp.com/join</p>
        <p className="text-mist text-xs">using the PIN above</p>
      </div>

      <div className="mb-8">
        <p className="text-mist text-xs mb-3">
          {players.length} player{players.length === 1 ? "" : "s"} joined
        </p>
        <div className="flex flex-wrap gap-2 min-h-[3rem]">
          {players.length === 0 ? (
            <p className="text-mist text-sm">Waiting for players…</p>
          ) : (
            players.map((p) => (
              <span
                key={p.id}
                className="bg-panel border border-line rounded-block px-3 py-1.5 text-sm"
              >
                {p.name}
              </span>
            ))
          )}
        </div>
      </div>

      <button
        onClick={onStart}
        disabled={busy || players.length === 0 || !hasQuestions}
        className="w-full bg-marigold text-ink font-display font-semibold text-lg py-4 rounded-block hover:brightness-105 transition disabled:opacity-40"
      >
        Start Question
      </button>
      {!hasQuestions && (
        <p className="text-coral text-xs mt-2">This quiz has no questions.</p>
      )}
    </div>
  );
}

function QuestionView({
  question,
  pct,
  secondsLeft,
  answeredCount,
  totalPlayers,
  optionCounts,
  onReveal,
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-2xl font-semibold max-w-xl">
          {question.question}
        </h2>
        <div className="timer-ring w-16 h-16 rounded-full flex items-center justify-center shrink-0" style={{ "--pct": pct }}>
          <div className="timer-ring-inner w-12 h-12 rounded-full flex items-center justify-center">
            <span className="font-display font-semibold">{secondsLeft}</span>
          </div>
        </div>
      </div>

      <p className="text-mist text-sm mb-4">
        {answeredCount} of {totalPlayers} answered
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
        {question.options.map((opt, i) => (
          <div
            key={i}
            className="bg-panel border border-line rounded-block px-4 py-4"
          >
            <div className="flex items-center justify-between mb-2">
              <span>{opt}</span>
              <span className="text-mist text-sm">{optionCounts[i]}</span>
            </div>
            <div className="h-1.5 bg-line rounded-full overflow-hidden">
              <div
                className="h-full bg-teal transition-all"
                style={{
                  width: `${
                    optionCounts.reduce((a, b) => a + b, 0) > 0
                      ? (optionCounts[i] /
                          Math.max(optionCounts.reduce((a, b) => a + b, 0), 1)) *
                        100
                      : 0
                  }%`,
                }}
              />
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={onReveal}
        className="w-full border border-line text-paper font-display py-3 rounded-block hover:border-mist transition"
      >
        Reveal answer now
      </button>
    </div>
  );
}

function RevealView({ question, optionCounts, leaderboard, isLast, busy, onNext }) {
  const total = optionCounts.reduce((a, b) => a + b, 0);
  return (
    <div>
      <h2 className="font-display text-2xl font-semibold mb-6">
        {question.question}
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
        {question.options.map((opt, i) => (
          <div
            key={i}
            className={`rounded-block px-4 py-4 border ${
              i === question.correctIndex
                ? "border-teal bg-teal/10"
                : "border-line bg-panel"
            }`}
          >
            <div className="flex items-center justify-between">
              <span>
                {opt}
                {i === question.correctIndex && (
                  <span className="text-teal text-xs ml-2">Correct</span>
                )}
              </span>
              <span className="text-mist text-sm">
                {optionCounts[i]}
                {total > 0 ? ` · ${Math.round((optionCounts[i] / total) * 100)}%` : ""}
              </span>
            </div>
          </div>
        ))}
      </div>

      <h3 className="font-display text-lg font-semibold mb-3 text-mist">
        Leaderboard
      </h3>
      <Leaderboard players={leaderboard} />

      <button
        onClick={onNext}
        disabled={busy}
        className="w-full mt-8 bg-marigold text-ink font-display font-semibold text-lg py-4 rounded-block hover:brightness-105 transition disabled:opacity-60"
      >
        {isLast ? "End quiz & show final results" : "Next Question"}
      </button>
    </div>
  );
}

function EndedView({ leaderboard, onViewLeaderboard }) {
  return (
    <div className="text-center">
      <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-3">
        QUIZ COMPLETE
      </p>
      <h2 className="font-display text-2xl font-semibold mb-6">
        Final leaderboard
      </h2>
      <Leaderboard players={leaderboard} />
      <button
        onClick={onViewLeaderboard}
        className="w-full mt-8 bg-marigold text-ink font-display font-semibold text-lg py-4 rounded-block hover:brightness-105 transition"
      >
        Open full-screen leaderboard
      </button>
    </div>
  );
}

function Leaderboard({ players }) {
  const top = players[0]?.score || 1;
  return (
    <ul className="flex flex-col gap-2">
      {players.length === 0 && (
        <p className="text-mist text-sm text-left">No players yet.</p>
      )}
      {players.map((p, i) => (
        <li
          key={p.id}
          className="relative overflow-hidden rounded-block bg-panelLight px-4 py-3"
        >
          <div
            className="absolute inset-y-0 left-0 bg-marigold/25"
            style={{ width: `${Math.max((p.score / top) * 100, 6)}%` }}
            aria-hidden
          />
          <div className="relative flex items-center justify-between">
            <span className="font-display font-semibold text-paper">
              {i + 1}. {p.name}
            </span>
            <span className="font-display font-semibold text-marigold">
              {p.score || 0}
            </span>
          </div>
        </li>
      ))}
    </ul>
  );
}

function CenteredMessage({ text }) {
  return (
    <main className="min-h-screen bg-ink text-mist flex items-center justify-center">
      <p>{text}</p>
    </main>
  );
}

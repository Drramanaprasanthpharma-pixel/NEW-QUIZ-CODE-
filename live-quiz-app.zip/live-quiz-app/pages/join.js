import Head from "next/head";
import { useState } from "react";
import { useRouter } from "next/router";
import {
  addDoc,
  collection,
  getDocs,
  query,
  serverTimestamp,
  where,
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { SESSION_STATUS } from "../lib/quizLogic";

export default function Join() {
  const router = useRouter();
  const [gamePin, setGamePin] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleJoin(e) {
    e.preventDefault();
    setError("");

    const pin = gamePin.trim();
    const playerName = name.trim();
    if (pin.length !== 6) {
      setError("Game PINs are 6 digits.");
      return;
    }
    if (!playerName) {
      setError("Enter a name so others can see you on the board.");
      return;
    }

    setBusy(true);
    try {
      const q = query(collection(db, "sessions"), where("gamePin", "==", pin));
      const snap = await getDocs(q);
      const candidates = snap.docs
        .map((d) => ({ id: d.id, ...d.data() }))
        .filter((s) => s.status !== SESSION_STATUS.ENDED)
        .sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));

      const session = candidates[0];
      if (!session) {
        setError("No live quiz found with that PIN.");
        return;
      }
      if (session.status !== SESSION_STATUS.LOBBY) {
        setError("This quiz has already started.");
        return;
      }

      const playerRef = await addDoc(
        collection(db, "sessions", session.id, "players"),
        {
          name: playerName,
          score: 0,
          joinedAt: serverTimestamp(),
        }
      );

      localStorage.setItem(
        "liveQuizPlayer",
        JSON.stringify({ sessionId: session.id, playerId: playerRef.id, name: playerName })
      );

      router.push("/play");
    } catch (err) {
      setError("Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Head>
        <title>Join Quiz · Live Quiz</title>
      </Head>
      <main className="min-h-screen bg-ink text-paper flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-sm">
          <p className="pin-display text-marigold text-sm tracking-[0.3em] mb-3">
            JOIN
          </p>
          <h1 className="font-display text-3xl font-semibold mb-1">
            Enter the game
          </h1>
          <p className="text-mist text-sm mb-8">
            Get the PIN from the host's screen.
          </p>

          <form onSubmit={handleJoin} className="flex flex-col gap-4">
            <div>
              <label className="block text-xs text-mist mb-1.5" htmlFor="pin">
                Game PIN
              </label>
              <input
                id="pin"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                value={gamePin}
                onChange={(e) => setGamePin(e.target.value.replace(/\D/g, ""))}
                placeholder="482931"
                className="pin-display w-full bg-panel border border-line rounded-block px-4 py-4 text-2xl text-center text-paper placeholder:text-mist/40"
              />
            </div>
            <div>
              <label className="block text-xs text-mist mb-1.5" htmlFor="name">
                Your name
              </label>
              <input
                id="name"
                maxLength={20}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Priya"
                className="w-full bg-panel border border-line rounded-block px-4 py-3 text-paper placeholder:text-mist/60"
              />
            </div>

            {error && (
              <p className="text-coral text-sm" role="alert">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="mt-2 w-full bg-marigold text-ink font-display font-semibold text-lg py-4 rounded-block hover:brightness-105 active:scale-[0.99] transition disabled:opacity-60"
            >
              {busy ? "Joining…" : "Join"}
            </button>
          </form>
        </div>
      </main>
    </>
  );
}

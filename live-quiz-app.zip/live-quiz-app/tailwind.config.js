/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#150C2B",
        panel: "#231447",
        panelLight: "#2E1B5C",
        line: "#3E2A72",
        marigold: "#FFC53D",
        teal: "#4FD1C5",
        coral: "#FF5470",
        mist: "#B7ACD9",
        paper: "#F6F3FF",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
      },
      borderRadius: {
        block: "10px",
      },
    },
  },
  plugins: [],
};
